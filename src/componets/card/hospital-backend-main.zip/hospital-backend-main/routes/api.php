<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\VdsController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\api\ValuteController;
use App\Http\Controllers\api\HostingController;
use App\Http\Controllers\api\PaymentsController;
use App\Http\Controllers\api\ReselingController;
use App\Http\Controllers\api\VdsOrderController;
use App\Http\Controllers\api\DomainTypeController;
use App\Http\Controllers\api\DomainOrderController;
use App\Http\Controllers\api\HeaderPostsController;
use App\Http\Controllers\api\HostingOrderController;
use App\Http\Controllers\api\ReselingOrderController;
use App\Http\Controllers\api\admin\VdsAdminController;
use App\Http\Controllers\api\admin\VpsAdminController;
use App\Http\Controllers\api\ReselingServerController;
use App\Http\Controllers\api\admin\UsersAdminController;
use App\Http\Controllers\api\admin\ValuteAdminController;
use App\Http\Controllers\api\admin\HostingAdminController;
use App\Http\Controllers\api\admin\LoginSessionController;
use App\Http\Controllers\api\admin\PaymentAdminController;
use App\Http\Controllers\api\admin\ReselingAdminController;
use App\Http\Controllers\api\admin\PromoCodeAdminController;
use App\Http\Controllers\api\admin\DomainTypeAdminController;
use App\Http\Controllers\api\admin\AdminHeaderPostsController;
use App\Http\Controllers\api\admin\ReselingServerAdminController;
use App\Http\Controllers\api\admin\AdminTechnologyCategoriesController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('user/forget',[AuthController::class,'forgetPassword']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/test1', function () {
    return 'salom';
});

Route::post('register',[AuthController::class,'register']);
Route::post('login',[AuthController::class,'login']);



Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('email/reset',[AuthController::class,'sendEmail']);
    Route::get('user',[AuthController::class,'user']);
    Route::post('user/edit/',[AuthController::class,'useredit']);
    Route::post('user/password-change/',[AuthController::class,'passwordChange']);
    Route::post('logout',[AuthController::class,'logout']);
    Route::post('email',[AuthController::class,'emailAuth']);
});





// Route::prefix('/domain-type')->group(function () {
//     Route::post('/',[DomainTypeAdminController::class,'add']);
//     Route::get('/',[DomainTypeAdminController::class,'get']);
//     Route::get('/{id}',[DomainTypeAdminController::class,'get']);
//     Route::put('/{id}',[DomainTypeAdminController::class,'edit']);
//     Route::delete('/{id}',[DomainTypeAdminController::class,'delete']);
//  });

