<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendingDoctor extends Model
{
    use HasFactory;
        protected $fillable = [
            'last_name',
            'first_name',
            'parent_name',
            'direction',
            'region_id',
            'user_id',
            'pol',
            'institution',
        ];

}
