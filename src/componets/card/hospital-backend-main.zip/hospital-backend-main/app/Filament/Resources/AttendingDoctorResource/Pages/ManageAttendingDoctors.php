<?php

namespace App\Filament\Resources\AttendingDoctorResource\Pages;

use App\Filament\Resources\AttendingDoctorResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ManageRecords;

class ManageAttendingDoctors extends ManageRecords
{
    protected static string $resource = AttendingDoctorResource::class;

    protected function getActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
