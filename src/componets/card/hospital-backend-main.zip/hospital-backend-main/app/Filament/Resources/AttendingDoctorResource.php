<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AttendingDoctorResource\Pages;
use App\Filament\Resources\AttendingDoctorResource\RelationManagers;
use App\Models\AttendingDoctor;
use App\Models\user;
use App\Models\Region;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class AttendingDoctorResource extends Resource
{
    protected static ?string $navigationLabel = 'Doktor';

        protected static ?string $model = AttendingDoctor::class;

        protected static ?string $navigationIcon = 'heroicon-o-collection';

        public static function form(Form $form): Form
        {

            return $form
                ->schema([
                    Forms\Components\Select::make('region_id')
                        ->label('Manzil')
                        ->options(Region::all()->pluck(['region_child',], 'id'))
                        ->searchable(),
                    Forms\Components\Select::make('user_id')
                        ->label('Foydalanuvchi')
                        ->options(User::where('type', false)->get()->pluck('name', 'id'))
                        ->searchable(),
                    Forms\Components\TextInput::make('institution')
                        ->label('Joylashuv')
                        ->required()
                        ->maxLength(191),
                    Forms\Components\Select::make('pol')
                        ->label('Jinsi')
                        ->options([
                            false => 'Erkak',
                            true => "Ayol",
                        ]),
                    Forms\Components\TextInput::make('last_name')->label("Familya")
                        ->required()
                        ->maxLength(191),
                    Forms\Components\TextInput::make('first_name')->label("Ism")
                        ->required()
                        ->maxLength(191),
                    Forms\Components\TextInput::make('parent_name')->label("Otchestva")
                        ->required()
                        ->maxLength(191),
                    Forms\Components\TextInput::make('direction')->label("Yo'nalish")
                        ->required()
                        ->maxLength(191),
                ]);
        }

        public static function table(Table $table): Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('region_id')->label("Manzil"),
                    Tables\Columns\TextColumn::make('user_id')->label("Foydalanuvchi"),
                    Tables\Columns\TextColumn::make('institution')->label("Manzil"),
                    Tables\Columns\IconColumn::make('pol')->label("Jinsi")
                        ->boolean(),
                    Tables\Columns\TextColumn::make('last_name')->label("Familya"),
                    Tables\Columns\TextColumn::make('first_name')->label("Ism"),
                    Tables\Columns\TextColumn::make('parent_name')->label("Otchestva"),
                    Tables\Columns\TextColumn::make('direction')->label("Yo'naishi"),
                    Tables\Columns\TextColumn::make('created_at')->label("Qo'shilgan vaqti")
                        ->dateTime(),
                    Tables\Columns\TextColumn::make('updated_at')->label('Yangilangan vaqti')
                        ->dateTime(),
                ])
                ->filters([
                    //
                ])
                ->actions([
                    Tables\Actions\EditAction::make(),
                    Tables\Actions\DeleteAction::make(),
                ])
                ->bulkActions([
                    Tables\Actions\DeleteBulkAction::make(),
                ]);
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ManageAttendingDoctors::route('/'),
            ];
        }
    }
