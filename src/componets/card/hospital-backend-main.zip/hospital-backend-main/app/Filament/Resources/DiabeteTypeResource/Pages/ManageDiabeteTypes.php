<?php

namespace App\Filament\Resources\DiabeteTypeResource\Pages;

use App\Filament\Resources\DiabeteTypeResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ManageRecords;

class ManageDiabeteTypes extends ManageRecords
{
    protected static string $resource = DiabeteTypeResource::class;

    protected function getActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
