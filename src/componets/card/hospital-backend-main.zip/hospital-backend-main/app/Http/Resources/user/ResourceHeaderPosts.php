<?php

namespace App\Http\Resources\user;

use App\Models\En;
use App\Models\Ru;
use App\Models\Uz;
use App\Http\Resources\user\ResourceUz;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceHeaderPosts extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'photo_small' =>'http://127.0.0.1:8000/'. $this->photo_small,
            'photo_big' =>'http://127.0.0.1:8000/'. $this->photo_big,
            'path' => $this->path,
            'translation' =>[
                'ru'=>new ResourceUz(Ru::where('post_id', $this->id)->get()->last()),
                'en'=>new ResourceUz(En::where('post_id', $this->id)->get()->last()),
                'uz'=>new ResourceUz(Uz::where('post_id', $this->id)->get()->last()),
            ],

        ];
    }
}
