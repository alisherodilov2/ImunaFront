<?php

namespace App\Http\Resources\admin;

use App\Models\VdsPostEn;
use App\Models\VdsPostRu;
use App\Models\VdsPostUz;
use App\Models\PriceProduct;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceVds extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'tariff' => $this->tariff,
            'ssd' => +$this->ssd,
            'ram' => +$this->ram,
            'cpu' => +$this->cpu,
            'cron' => +$this->cron,
            'domain' => $this->domain,
            'email' => $this->email,
            'nvm' => $this->nvm,
            'protsessor' => $this->protsessor,
            'ftp' => $this->ftp,
            'mbs_network' => $this->mbs_network,
            'translation' =>[
                'ru'=>VdsPostUz::where('post_id', $this->id)->get()->last(),
                'en'=>VdsPostRu::where('post_id', $this->id)->get()->last(),
                'uz'=>VdsPostEn::where('post_id', $this->id)->get()->last(),
            ],
            'price' => PriceProduct::where('vds_id', $this->id)->get(),
            'status' => $this->status,


        ];
    }
}
