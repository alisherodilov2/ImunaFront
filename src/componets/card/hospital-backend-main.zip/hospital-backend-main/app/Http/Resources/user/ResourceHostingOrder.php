<?php

namespace App\Http\Resources\user;

use App\Models\Hostings;
use App\Http\Resources\user\ResourceHostings;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceHostingOrder extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'hosting' => new ResourceHostings(Hostings::find($this->hosting_id)),
            'price' => +$this->price,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'status' => $this->status,
        ];
    }
}
