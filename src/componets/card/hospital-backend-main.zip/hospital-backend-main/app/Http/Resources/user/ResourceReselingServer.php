<?php

namespace App\Http\Resources\user;

use App\Models\Reselings;
use App\Http\Resources\user\ResourceReselings;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceReselingServer extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'reseling' => new ResourceReselings(Reselings::find($this->reseling_id)),
            'name' => $this->name,
            'users' => $this->users,
            'ftp' => $this->ftp,
            'domain' => $this->domain,
            'sub_domain' => $this->sub_domain,
            'day_price' => +$this->day_price,
            'month_price' => +$this->month_price,
            'year_price' => +$this->year_price,
            'memory' => $this->memory,
        ];
    }
}
