<?php

namespace App\Http\Resources\admin;

use App\Models\HostingPrice;
use App\Models\HostingPostEn;
use App\Models\HostingPostRu;
use App\Models\HostingPostUz;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceHosting extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'ssd' => +$this->ssd,
            'sub_domain' => $this->sub_domain,
            'database_domain' => $this->database_domain,
            'email' => $this->email,
            'sub_domain' => $this->sub_domain,
            'ftp' => $this->ftp,
            'ram' => +$this->ram,
            'moth_1_price' => +$this->moth_1_price,
            'moth_3_price' => +$this->moth_3_price,
            'moth_6_price' => +$this->moth_6_price,
            'moth_12_price' => +$this->moth_12_price,
            'moth_24_price' => +$this->moth_24_price,
            'mbs_network' => $this->mbs_network,
            'translation' =>[
                'ru'=>HostingPostRu::where('post_id', $this->id)->get()->last(),
                'en'=>HostingPostUz::where('post_id', $this->id)->get()->last(),
                'uz'=>HostingPostEn::where('post_id', $this->id)->get()->last(),
            ],
            'price' => HostingPrice::where('hosting_id', $this->id)->get()->last(),
            'status' => $this->status,
        ];
    }
}
