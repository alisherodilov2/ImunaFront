<?php

namespace App\Http\Resources;

use App\Models\Reselings;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceReselings extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'reseling' => Reselings::find($this->reseling_id),
            'reseling_data' => $this->reseling,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];

    }
}
