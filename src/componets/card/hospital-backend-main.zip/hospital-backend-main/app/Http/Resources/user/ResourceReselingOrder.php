<?php

namespace App\Http\Resources\user;

use App\Models\Reselings;
use App\Models\ReselingServers;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\user\ResourceReselingServer;

class ResourceReselingOrder extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'reseling' => new ResourceReselingServer(ReselingServers::find($this->reselings_server_id)),
            'price' => +$this->price,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'status' => $this->status,
        ];
    }
}
