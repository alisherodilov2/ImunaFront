<?php

namespace App\Http\Resources\user;

use App\Models\Valute;
use App\Http\Resources\user\ResourceValute;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceUser extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'last_name'=>$this->last_name,
            'first_name'=>$this->first_name,
            'phone'=>$this->phone,
            'balance'=>+$this->balance,
            'adress'=>$this->adress,
            'img'=>'http://127.0.0.1:8000/'.$this->img,
            'login'=>$this->login,
            'lock'=>$this->lock,
            'valute'=>$this->valute,
            'type'=>$this->type,
            'auth'=>$this->auth===0 ? false : true,
            'email'=>$this->email,
            'valute_price'=>new ResourceValute( Valute::where('status', 1)->get()->last())
        ];
    }
}
