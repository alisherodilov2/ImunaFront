<?php

namespace App\Http\Resources\user;

use Illuminate\Http\Resources\Json\JsonResource;

class ResourceReselings extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
         return [
            'id' => $this->id,
            'address' => $this->address,
            'protsessor' => $this->protsessor,
            'mbs_network' => $this->mbs_network,
            'panel' => $this->panel,
            'ip' => $this->ip,
            'ns1' => $this->ns1,
            'ns2' => $this->ns2,
        ];
    }
    // $table->increments('id');
    // $table->string('address');
    // $table->string('protsessor');
    // $table->integer('mbs_network');
    // $table->string('panel');
    // $table->string('ip');
    // $table->string('ns1');
    // $table->string('ns2');
    // $table->boolean('status')->default(false);
}
