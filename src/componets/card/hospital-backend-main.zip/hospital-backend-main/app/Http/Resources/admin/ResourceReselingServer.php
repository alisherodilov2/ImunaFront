<?php

namespace App\Http\Resources\admin;

use App\Models\Reselings;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceReselingServer extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'reseling' => Reselings::find($this->reseling_id),
            // 'reseling' =>$this->reselingData,
            // 'reseling1' =>Reselings::where('id',$this->reseling_id)->get()->last(),
            'name' => $this->name,
            'users' => $this->users,
            'ftp' => $this->ftp,
            'domain' => $this->domain,
            'sub_domain' => $this->sub_domain,
            'day_price' => $this->day_price,
            'month_price' => $this->month_price,
            'year_price' => $this->year_price,
            'memory' => $this->memory,
            'status' => $this->status,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
