<?php

namespace App\Http\Resources\user;

use App\Models\Vds;
use App\Http\Resources\user\ResourceVds;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceVdsOrder extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'vds' => new ResourceVds(Vds::find($this->vds_id)),
            'price' => +$this->price,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'status' => $this->status,
        ];
    }
}
