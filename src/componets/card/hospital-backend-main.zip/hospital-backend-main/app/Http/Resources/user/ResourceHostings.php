<?php

namespace App\Http\Resources\user;

use App\Models\Valute;
use App\Models\HostingPrice;
use App\Models\HostingPostEn;
use App\Models\HostingPostRu;
use App\Models\HostingPostUz;
use Illuminate\Http\Resources\Json\JsonResource;

class ResourceHostings extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)

    {
        $valute = Valute::where('status',1)->get()->last();
        $price = HostingPrice::where('hosting_id', $this->id)->get()->last();
        return [
            'id' => $this->id,
            'name' => $this->name,
            'ssd' => +$this->ssd,
            'sub_domain' => $this->sub_domain,
            'database_domain' => $this->database_domain,
            'email' => $this->email,
            'sub_domain' => $this->sub_domain,
            'ftp' => $this->ftp,
            'ram' => +$this->ram,
            'mbs_network' => $this->mbs_network,
            'translation' =>[
                'ru'=>new ResourceUz(HostingPostRu::where('post_id', $this->id)->get()->last()),
                'en'=>new ResourceUz(HostingPostEn::where('post_id', $this->id)->get()->last()),
                'uz'=>new ResourceUz(HostingPostUz::where('post_id', $this->id)->get()->last()),
            ],
            'price' =>[
                'uzs'=>[
                    'day'=> [
                        'price'=>(+$price->day-(+$price->day/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->day-(+$price->day/100)*$valute->discount_uzs) - ((+$price->day-(+$price->day/100)*$valute->discount_uzs)/100-$price->day_discount),
                        'discount'=>+$price->day_discount
                    ],
                    'week'=> [
                        'price'=>(+$price->week-(+$price->week/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->week-(+$price->week/100)*$valute->discount_uzs) - ((+$price->week-(+$price->week/100)*$valute->discount_uzs)/100-$price->week_discount),
                        'discount'=>+$price->week_discount
                    ],
                    'month'=> [
                        'price'=>(+$price->month-(+$price->month/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->month-(+$price->month/100)*$valute->discount_uzs) - ((+$price->month-(+$price->month/100)*$valute->discount_uzs)/100-$price->month_discount),
                        'discount'=>+$price->month_discount
                    ],
                    'month_3'=> [
                        'price'=>(+$price->month_3-(+$price->month_3/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->month_3-(+$price->month_3/100)*$valute->discount_uzs) - ((+$price->month_3-(+$price->month_3/100)*$valute->discount_uzs)/100-$price->month_3_discount),
                        'discount'=>+$price->month_3_discount
                    ],
                    'month_6'=> [
                        'price'=>(+$price->month_6-(+$price->month_6/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->month_6-(+$price->month_6/100)*$valute->discount_uzs) - ((+$price->month_6-(+$price->month_6/100)*$valute->discount_uzs)/100-$price->month_6_discount),
                        'discount'=>+$price->month_6_discount
                    ],
                    'month_12'=> [
                        'price'=>(+$price->month_12-(+$price->month_12/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->month_12-(+$price->month_12/100)*$valute->discount_uzs) - ((+$price->month_12-(+$price->month_12/100)*$valute->discount_uzs)/100-$price->month_12_discount),
                        'discount'=>+$price->month_12_discount
                    ],
                    'month_24'=> [
                        'price'=>(+$price->month_24-(+$price->month_24/100)*$valute->discount_uzs),
                        'price_item'=>(+$price->month_24-(+$price->month_24/100)*$valute->discount_uzs) - ((+$price->month_24-(+$price->month_24/100)*$valute->discount_uzs)/100-$price->month_24_discount),
                        'discount'=>+$price->month_24_discount
                    ],
                ],
                'usd'=>[
                    'day'=> [
                        'price'=>(+$price->day-(+$price->day/100)*$valute->discount_usd)  / $valute->sell_usd,
                        'price_item'=>((+$price->day-(+$price->day/100)*$valute->discount_usd) - ((+$price->day-(+$price->day/100)*$valute->discount_usd)/100-$price->day_discount)) /  $valute->sell_usd,
                        'discount'=>+$price->day_discount
                    ],
                    'week'=> [
                        'price'=>(+$price->week-(+$price->week/100)*$valute->discount_usd) / $valute->sell_usd,
                        'price_item'=>((+$price->week-(+$price->week/100)*$valute->discount_usd) - ((+$price->week-(+$price->week/100)*$valute->discount_usd)/100-$price->week_discount)) / $valute->sell_usd,
                        'discount'=>+$price->week_discount
                    ],
                    'month'=> [
                        'price'=>(+$price->month-(+$price->month/100)*$valute->discount_usd) /  $valute->sell_usd,
                        'price_item'=>((+$price->month-(+$price->month/100)*$valute->discount_usd) - ((+$price->month-(+$price->month/100)*$valute->discount_usd)/100-$price->month_discount)) /  $valute->sell_usd,
                        'discount'=>+$price->month_discount
                    ],
                    'month_3'=> [
                        'price'=>(+$price->month_3-(+$price->month_3/100)*$valute->discount_usd) /  $valute->sell_usd,
                        'price_item'=>((+$price->month_3-(+$price->month_3/100)*$valute->discount_usd) - ((+$price->month_3-(+$price->month_3/100)*$valute->discount_usd)/100-$price->month_3_discount)) /  $valute->sell_usd,
                        'discount'=>+$price->month_3_discount
                    ],
                    'month_6'=> [
                        'price'=>(+$price->month_6-(+$price->month_6/100)*$valute->discount_usd) /  $valute->sell_usd,
                        'price_item'=>((+$price->month_6-(+$price->month_6/100)*$valute->discount_usd) - ((+$price->month_6-(+$price->month_6/100)*$valute->discount_usd)/100-$price->month_6_discount)) /  $valute->sell_usd,
                        'discount'=>+$price->month_6_discount
                    ],
                    'month_12'=> [
                        'price'=>(+$price->month_12-(+$price->month_12/100)*$valute->discount_usd) /  $valute->sell_usd,
                        'price_item'=>((+$price->month_12-(+$price->month_12/100)*$valute->discount_usd) - ((+$price->month_12-(+$price->month_12/100)*$valute->discount_usd)/100-$price->month_12_discount) )/  $valute->sell_usd,
                        'discount'=>+$price->month_12_discount
                    ],
                    'month_24'=> [
                        'price'=>(+$price->month_24-(+$price->month_24/100)*$valute->discount_usd) /  $valute->sell_usd,
                        'price_item'=>((+$price->month_24-(+$price->month_24/100)*$valute->discount_usd) - ((+$price->month_24-(+$price->month_24/100)*$valute->discount_usd)/100-$price->month_24_discount)) /  $valute->sell_usd,
                        'discount'=>+$price->month_24_discount
                    ],
                ],
                'rubl'=>[
                    'day'=> [
                        'price'=>(+$price->day-(+$price->day/100)*$valute->discount_rubl)  / $valute->sell_rubl,
                        'price_item'=>((+$price->day-(+$price->day/100)*$valute->discount_rubl) - ((+$price->day-(+$price->day/100)*$valute->discount_rubl)/100-$price->day_discount)) /  $valute->sell_rubl,
                        'discount'=>+$price->day_discount
                    ],
                    'week'=> [
                        'price'=>(+$price->week-(+$price->week/100)*$valute->discount_rubl) / $valute->sell_rubl,
                        'price_item'=>((+$price->week-(+$price->week/100)*$valute->discount_rubl) - ((+$price->week-(+$price->week/100)*$valute->discount_rubl)/100-$price->week_discount)) / $valute->sell_rubl,
                        'discount'=>+$price->week_discount
                    ],
                    'month'=> [
                        'price'=>(+$price->month-(+$price->month/100)*$valute->discount_rubl) /  $valute->sell_rubl,
                        'price_item'=>((+$price->month-(+$price->month/100)*$valute->discount_rubl) - ((+$price->month-(+$price->month/100)*$valute->discount_rubl)/100-$price->month_discount)) /  $valute->sell_rubl,
                        'discount'=>+$price->month_discount
                    ],
                    'month_3'=> [
                        'price'=>(+$price->month_3-(+$price->month_3/100)*$valute->discount_rubl) /  $valute->sell_rubl,
                        'price_item'=>((+$price->month_3-(+$price->month_3/100)*$valute->discount_rubl) - ((+$price->month_3-(+$price->month_3/100)*$valute->discount_rubl)/100-$price->month_3_discount)) /  $valute->sell_rubl,
                        'discount'=>+$price->month_3_discount
                    ],
                    'month_6'=> [
                        'price'=>(+$price->month_6-(+$price->month_6/100)*$valute->discount_rubl) /  $valute->sell_rubl,
                        'price_item'=>((+$price->month_6-(+$price->month_6/100)*$valute->discount_rubl) - ((+$price->month_6-(+$price->month_6/100)*$valute->discount_rubl)/100-$price->month_6_discount)) /  $valute->sell_rubl,
                        'discount'=>+$price->month_6_discount
                    ],
                    'month_12'=> [
                        'price'=>(+$price->month_12-(+$price->month_12/100)*$valute->discount_rubl) /  $valute->sell_rubl,
                        'price_item'=>((+$price->month_12-(+$price->month_12/100)*$valute->discount_rubl) - ((+$price->month_12-(+$price->month_12/100)*$valute->discount_rubl)/100-$price->month_12_discount) )/  $valute->sell_rubl,
                        'discount'=>+$price->month_12_discount
                    ],
                    'month_24'=> [
                        'price'=>(+$price->month_24-(+$price->month_24/100)*$valute->discount_rubl) /  $valute->sell_rubl,
                        'price_item'=>((+$price->month_24-(+$price->month_24/100)*$valute->discount_rubl) - ((+$price->month_24-(+$price->month_24/100)*$valute->discount_rubl)/100-$price->month_24_discount)) /  $valute->sell_rubl,
                        'discount'=>+$price->month_24_discount
                    ],
                ],
            ],
        ];
    }
}
