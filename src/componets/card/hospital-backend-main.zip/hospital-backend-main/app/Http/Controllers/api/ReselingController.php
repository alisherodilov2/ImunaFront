<?php

namespace App\Http\Controllers\api;

use App\Models\Reselings;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\user\ResourceReselings;

class ReselingController extends Controller
{
    //
    public function get(Request $request, $id=false){
        if($id){
            $reseling = ResourceReselings::collection( Reselings::where(['status'=> 1,'id'=>$id])->first());
            return $reseling;
        }else{
            $reseling =ResourceReselings::collection( Reselings::where('status',1)->get());
            return $reseling;
        }

    }
}
