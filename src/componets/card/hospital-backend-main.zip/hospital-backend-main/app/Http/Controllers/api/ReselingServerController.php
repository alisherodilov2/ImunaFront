<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Models\ReselingServers;
use App\Http\Controllers\Controller;
use App\Http\Resources\user\ResourceReselingServer;

class ReselingServerController extends Controller
{
    //
    public function get(Request $request, $id=false){
        if($id){
            $reselingserver = ResourceReselingServer::collection( ReselingServers::where(['status'=>1,'reseling_id'=>$id])->get());
            return $reselingserver;
        }else{
            $reselingserver =  ReselingServers::where(['status'=>1,'reseling_id'=>$id])->get();
            return $reselingserver;
        }

    }
}
