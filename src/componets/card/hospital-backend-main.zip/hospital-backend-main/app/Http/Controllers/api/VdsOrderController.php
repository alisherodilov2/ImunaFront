<?php

namespace App\Http\Controllers\api;

use App\Models\Vds;
use App\Models\VdsOrder;
use App\Models\VdsOrders;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\user\ResourceUser;
use App\Http\Resources\user\ResourceVdsOrder;

class VdsOrderController extends Controller
{
    //
    public function order(Request $request){
        $user = Auth::user() ?? false;
        if($user){
        $vdsorder = new VdsOrders();
        $vdsorder->user_id = $user->id;
        $vdsorder->price =  $request->input('price');
        $user->balance = $user->balance-$request->input('price');
        $user->save();
        $now = date('Y-m-d H:i:s');
        $vdsorder->start_date =  $now ;
        $vdsorder->end_date = date('Y-m-d H:i:s',strtotime( $now."+ ".$request->input('data')."month") ) ;
        $vdsorder->user = json_encode($user);
        $vdsorder->vds_id = $request->input('vds_id');
        $vdsorder->status = 'tolandi';
        $vdsorder->vds =json_encode(Vds::find($request->input('id')));
        $vdsorder->save();
        $user['balances'] = +$user->balance;
        return response()->json([
            'status'=>200,
            "user" =>new ResourceUser($user),
            'data'=>new ResourceVdsOrder( $vdsorder)
        ]);
        }
    }
    public function get(Request $request, $id=false){
        $user = Auth::user();
        if($id){
            $vdsorder = new ResourceVdsOrder( VdsOrders::find($id));
            return $vdsorder;
        }else{
            $vdsorder = ResourceVdsOrder::collection( VdsOrders::where('user_id', $user->id)->get());
            return $vdsorder;
        }
    }
}
