<?php

namespace App\Http\Controllers\api;

use App\Models\HeaderPosts;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\user\ResourceHeaderPosts;

class HeaderPostsController extends Controller
{
    //
    public function get(Request $request, $id=false){
        if($id){
            $hosting =new ResourceHeaderPosts(HeaderPosts::where(['status'=> 1,'id'=>$id])->first());
            return $hosting;
        }else{
            $hosting = ResourceHeaderPosts::collection(HeaderPosts::where('status',1)->get());
            return $hosting;
        }

    }
}
