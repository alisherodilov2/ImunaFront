<?php

namespace App\Http\Controllers\api;

use App\Models\Hostings;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\user\ResourceHostings;

class HostingController extends Controller
{
    //
    public function get(Request $request, $id=false){
        if($id){
            $hosting =new ResourceHostings(Hostings::where(['status'=> 1,'id'=>$id])->first());
            return $hosting;
        }else{
            $hosting = ResourceHostings::collection(Hostings::where('status',1)->get());
            return $hosting;
        }

    }
}
