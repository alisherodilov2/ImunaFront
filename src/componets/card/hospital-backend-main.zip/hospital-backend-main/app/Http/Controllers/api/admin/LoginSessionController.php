<?php

namespace App\Http\Controllers\api\admin;

use App\Models\LoginSession;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\user\ResourceLoginSession;

class LoginSessionController extends Controller
{
    //
    public function get(Request $request, $id=false){
        $user = Auth::user();
        if($user->type===0){

               $domintype =ResourceLoginSession::collection( LoginSession::where('user_id',$user->id)->get());
            return $domintype;
        }else{
            if($id){
                $domintype = LoginSession::find($id);
                return $domintype;
            }else{
                $domintype = LoginSession::paginate(2);
                return $domintype;
            }
        }

    }
    public function delete($id=false){
        $domintype = LoginSession::find($id);
        if($domintype){
            $domintype->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'domintype not found!'
            ]);
        }
    }
}
