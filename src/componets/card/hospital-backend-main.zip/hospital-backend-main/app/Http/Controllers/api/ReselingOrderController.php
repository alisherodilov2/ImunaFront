<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Models\ReselingOrders;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\user\ResourceUser;
use App\Http\Resources\user\ResourceReselingOrder;

class ReselingOrderController extends Controller
{
    public function order(Request $request){
        $user = Auth::user() ?? false;
        if($user){
        $reselingorder = new ReselingOrders();
        $reselingorder->user_id = $user->id;
        $reselingorder->price =  $request->input('price');
        $user->balance = $user->balance-$request->input('price');
        $user->save();
        $now = date('Y-m-d H:i:s');
        $reselingorder->start_date =  $now ;
        $reselingorder->end_date = date('Y-m-d H:i:s',strtotime( $now."+ ".$request->input('data')) ) ;
        $reselingorder->reselings_server_id = $request->input('id');
        $reselingorder->status = 'tolandi';
        $reselingorder->save();
        $user['balances'] = +$user->balance;
        return response()->json([
            'status'=>200,
            "user" =>new ResourceUser($user),
            'data'=>new ResourceReselingOrder( $reselingorder)
        ]);
        }
    }
    public function get(Request $request, $id=false){
        $user = Auth::user();
        if($id){
            $reselingorder = new ResourceReselingOrder(ReselingOrders::find($id));
            return $reselingorder;
        }else{
            $reselingorder = ResourceReselingOrder::collection( ReselingOrders::where('user_id', $user->id)->get());
            return $reselingorder;
        }
    }
}
