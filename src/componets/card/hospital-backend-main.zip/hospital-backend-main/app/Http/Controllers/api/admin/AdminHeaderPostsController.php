<?php

namespace App\Http\Controllers\api\admin;

use App\Models\En;
use App\Models\Ru;
use App\Models\Uz;
use App\Models\HeaderPosts;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\admin\ResourceHeaderPosts;

class AdminHeaderPostsController extends Controller
{
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'photo_big' => 'required|mimetypes:image/jpeg,image/png,image/gif,image/svg',
            'photo_small' => 'required|mimetypes:image/jpeg,image/png,image/gif,image/svg',
            'ens_header' => 'required',
            'ens_title' => 'required',
            'rus_header' => 'required',
            'rus_title' => 'required',
            'uzs_title' => 'required',
            'uzs_header' => 'required',
            'path' => 'required',
            'status' => 'required|boolean',
        ]);
        $headerpost = new HeaderPosts();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            if ($request->hasFile('photo_big')) {
                $file1 = $request->file('photo_big');
                $ext1 = $file1->getClientOriginalExtension();
                $fileName1 = time() .md5('photo_big'). '.' . $ext1;
                $file1->move('header/', $fileName1);
                $headerpost->photo_big = "header/" . $fileName1;
            }
            if ($request->hasFile('photo_small')) {
                $file = $request->file('photo_small');
                $ext = $file->getClientOriginalExtension();
                $fileName = time() .md5('photo_small'). '.' . $ext;
                $file->move('header/', $fileName);
                $headerpost->photo_small = "header/" . $fileName;
            }
            $ru = new Ru();
            $en = new En();
            $uz = new Uz();
            $headerpost->status = $request->input('status');
            $headerpost->path = $request->input('path');
            $headerpost->save();
            $ru->title = $request->input('rus_title');
            $ru->header = $request->input('rus_header');
            $ru->post_id = $headerpost->id;

            $en->title = $request->input('ens_title');
            $en->header = $request->input('ens_header');
            $en->post_id = $headerpost->id;

            $uz->title = $request->input('uzs_title');
            $uz->header = $request->input('uzs_header');
            $uz->post_id = $headerpost->id;
            $uz->save();
            $en->save();
            $ru->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype add!',
                'data' => new ResourceHeaderPosts($headerpost)
            ]);
        }
    }
    // // // get
    public function get(Request $request, $id=false){
        if($id){
            $headerpost = new ResourceHeaderPosts( HeaderPosts::find($id));
            return $headerpost;
        }else{
            $headerpost = ResourceHeaderPosts::collection( HeaderPosts::paginate(2));
            return $headerpost;
        }

    }
    // // // edit
    public function edit(Request $request,$id=false){
        if($id){
        $headerpost = HeaderPosts::find($id);
        $validator = Validator::make($request->all(), [
            'photo_big' => 'mimetypes:image/jpeg,image/png,image/gif,image/svg',
            'photo_small' => 'mimetypes:image/jpeg,image/png,image/gif,image/svg',
            'status' => 'boolean',
        ]);
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{

            if ($request->hasFile('photo_big')) {
                $file1 = $request->file('photo_big');
                $ext1 = $file1->getClientOriginalExtension();
                $fileName1 = time() .md5('photo_big'). '.' . $ext1;
                $file1->move('header/', $fileName1);
                $headerpost->photo_big = "header/" . $fileName1;
            }else{
                $headerpost->photo_big = $headerpost->photo_big;
            }
            if ($request->hasFile('photo_small')) {
                $file = $request->file('photo_small');
                $ext = $file->getClientOriginalExtension();
                $fileName = time() .md5('photo_small'). '.' . $ext;
                $file->move('header/', $fileName);
                $headerpost->photo_small = "header/" . $fileName;
            }else{
                $headerpost->photo_small =  $headerpost->photo_small;
            }
            $ru = Ru::find($request->input('ru_id'));
            $en = En::find($request->input('en_id'));
            $uz = Uz::find($request->input('uz_id'));

            $headerpost->status = $request->input('status') ??   $headerpost->status;
            $headerpost->path = $request->input('path') ??    $headerpost->path;
            $headerpost->save();

            // $ru->title  = $request->input('rus_title') ??     $ru->title;
            // $ru->header = $request->input('rus_header') ??    $ru->header;
            // $ru->post_id = $headerpost->id;

            // $en->title = $request->input('ens_title') ??   $en->title;
            // $en->header = $request->input('ens_header') ??   $en->header;
            // $en->post_id = $headerpost->id;

            // $uz->title = $request->input('uzs_title') ??  $uz->title ;
            // $uz->header = $request->input('uzs_header') ??   $uz->header;
            // $uz->post_id = $headerpost->id;
            // $uz->save();
            // $en->save();
            // $ru->save();
            return response()->json([
                // 'status'=>200,
                'status1'=>Ru::all(),
                // 'xabar'=>'header post edit!',
                // 'data' => new ResourceHeaderPosts($headerpost)
            ]);
            }
        }
        else{
            return response()->json([
                'status'=>404,
                'xabar'=>'Not found 404',
            ]);
        }
    }
    // // // // // delete
    public function delete($id=false){
        $headerpost = HeaderPosts::find($id);
        if($headerpost){
            $image_path = app_path($headerpost->photo_small);
            $image_path2 = app_path($headerpost->photo_big);

            if (File::exists($image_path) && File::exists($image_path2)) {
                //File::delete($image_path);
                unlink($image_path);
                unlink($image_path2);
            }

            $headerpost->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'domintype not found!'
            ]);
        }
    }

}
