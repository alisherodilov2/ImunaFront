<?php

namespace App\Http\Controllers\api\admin;

use App\Models\Valute;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class ValuteAdminController extends Controller
{
    //
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'rubl' => 'required|numeric',
            'usd' => 'required|numeric',
            'sell_rubl' => 'required|numeric',
            'sell_usd' => 'required|numeric',
            'discount_uzs' => 'required|integer',
            'discount_usd' => 'required|integer',
            'discount_rubl' => 'required|integer',
        ]);
        $valute = new Valute();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $valute->rubl = $request->input('rubl');
            $valute->usd = $request->input('usd');
            $valute->sell_rubl = $request->input('sell_rubl');
            $valute->discount_uzs = $request->input('discount_uzs');
            $valute->discount_usd = $request->input('discount_usd');
            $valute->discount_rubl = $request->input('discount_rubl');
            $valute->sell_usd = $request->input('sell_usd');
            $valute->status = $request->input('status') ?? false;
            $valute->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'Payments add!',
                'data' => $valute
            ]);

        }
    }
    // // // // get
    public function get(Request $request, $id=false){
        if($id){
            $val = Valute::find($id);
            return $val;
        }else{
            $val = Valute::paginate(2);
                        return $val;
        }
    }
    // // // // edit
    public function edit(Request $request,$id=false){
        $validator = Validator::make($request->all(), [
            'rubl' => 'numeric',
            'usd' => 'numeric',
            'sell_rubl' => 'numeric',
            'sell_usd' => 'numeric',
            'discount_uzs' => 'integer',
            'discount_usd' => 'integer',
            'discount_rubl' => 'integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            if($id){
            $valute = Valute::find($id);

            $valute->rubl = $request->input('rubl') ?? $valute->rubl;
            $valute->usd = $request->input('usd') ?? $valute->usd;
            $valute->status = $request->input('status') ?? $valute->status;

            $valute->sell_rubl = $request->input('sell_rubl') ?? $valute->sell_rubl;
            $valute->sell_usd = $request->input('sell_usd') ?? $valute->sell_usd;

            $valute->discount_uzs = $request->input('discount_uzs') ?? $valute->discount_uzs ;
            $valute->discount_usd = $request->input('discount_usd') ?? $valute->discount_usd;
            $valute->discount_rubl = $request->input('discount_rubl') ??  $valute->discount_rubl;

            $valute->save();
                return response()->json([
                    'status'=>200,
                    'xabar'=>'valute edit!',
                    'data' => $valute
                ]);

            }else{
                return response()->json([
                    'status'=>404,
                    'xabar'=>' valute Not found 404',
                ]);

            }
        }


    }
    // // // // delete
    public function delete($id=false){
        $valute = Valute::find($id);
        if($valute){
            $valute->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'valute delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'valute not found!'
            ]);
        }
    }
}
