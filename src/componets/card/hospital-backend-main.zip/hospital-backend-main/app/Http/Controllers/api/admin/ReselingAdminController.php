<?php

namespace App\Http\Controllers\api\admin;

use App\Models\Reselings;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\ResourceReselings;
use Illuminate\Support\Facades\Validator;

class ReselingAdminController extends Controller
{
      //add
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'address' => 'required',
            'mbs_network' => 'required|numeric',
            'panel' => 'required',
            'ip' => 'required',
            'ns1' => 'required',
            'protsessor' => 'required',
            'ns2' => 'required',
            'status' => 'required|boolean',
        ]);
        $reseling = new Reselings();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $reseling->address = $request->input('address');
            $reseling->mbs_network = $request->input('mbs_network');
            $reseling->panel = $request->input('panel');
            $reseling->ip = $request->input('ip');
            $reseling->protsessor = $request->input('protsessor');
            $reseling->ns1 = $request->input('ns1');
            $reseling->ns2 = $request->input('ns2');
            $reseling->status = $request->input('status');
            $reseling->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'Reseling add!',
                'data' =>$reseling
            ]);
        }
    }
    // get
    public function get(Request $request, $id=false){
        if($id){
            $reseling =  Reselings::find($id);
            return $reseling;
        }else{
            // $reseling = ResourceReselings::collection(Reselings::paginate(2));
            $reseling = (Reselings::paginate(2));
            return $reseling;
        }
    }

    // // edit
    public function edit(Request $request,$id=false){
            if ($id) {
                $reseling = Reselings::find($id) ?? false;
                if ($reseling) {
                    $validator = Validator::make($request->all(), [
                        'mbs_network' => 'numeric',
                    ]);
                    if ($validator->fails()) {
                        return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
                    } else {
                        $reseling->address = $request->input('address') ?? $reseling->address;
                        $reseling->mbs_network = $request->input('mbs_network') ?? $reseling->mbs_network;
                        $reseling->panel = $request->input('panel') ?? $reseling->panel;
                        $reseling->ip = $request->input('ip') ?? $reseling->ip;
                        $reseling->protsessor = $request->input('protsessor') ?? $reseling->protsessor;
                        $reseling->ns1 = $request->input('ns1') ?? $reseling->ns1;
                        $reseling->ns2 = $request->input('ns2') ?? $reseling->ns2;
                        $reseling->status = $request->input('status') ?? $reseling->status;
                        return response()->json([
                            'status'=>200,
                            'xabar'=>'rese$reseling edit!',
                            'data' => $reseling
                        ]);
                    }
                } else {
                    return response()->json([
                        'status'=>404,
                        'xabar'=>'Not found 404',
                    ]);
                }
            }else {
                return response()->json([
                    'status'=>404,
                    'xabar'=>'Not found 404',
                ]);
            }
    }
    // // // // delete
    public function delete($id=false){
        $reseling = Reselings::find($id);
        if($reseling){
            $reseling->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'pro$reseling delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'domintype not found!'
            ]);
        }
    }
}
