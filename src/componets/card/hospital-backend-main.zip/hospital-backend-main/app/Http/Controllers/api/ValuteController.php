<?php

namespace App\Http\Controllers\api;

use App\Models\Valute;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\user\ResourceValute;

class ValuteController extends Controller
{
    // // // // get
    public function get(Request $request, $id=false){


        return  ResourceValute::collection(Valute::where('status', 1)->get());
    }


}
