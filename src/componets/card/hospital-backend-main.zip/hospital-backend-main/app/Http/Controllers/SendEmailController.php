<?php

namespace App\Http\Controllers;

use App\Mail\NotifyMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class SendEmailController extends Controller
{
    //
    public function index()
    {

        $to_name = "RECEIVER_NAME";
        $to_email = "tomail@gmail.com";
        $data = array("name"=>"Cloudways (sender_name)", "body" => "A test mail");
        Mail::send([], $data, function($message) use ($to_name, $to_email) {
        $message->to($to_email, $to_name)
        ->subject("laravelda emailga habar jo'natish");
        $message->from("preealweb@gmail.com","Test Mail");
        });
      Mail::to('receiver-email-id')->send(new NotifyMail());

      if (Mail::failures()) {
           return response()->Fail('Sorry! Please try again latter');
      }else{
           return response()->success('Great! Successfully send in your mail');
         }
    }
}
