<?php

namespace App\Http\Controllers\api;

use App\Models\Valute;
use App\Models\Payments;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\user\ResourceUser;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\user\ResourcePayment;

class PaymentsController extends Controller
{
    //add
    public function payment(Request $request){
        $user = Auth::user() ?? false;
        $val = Valute::where('status', 1)->get()->last();
        if($user){
            $validator = Validator::make($request->all(), [
                'price' => 'required|numeric',
                'payment_type' => 'required',
                'payment_type_name' => 'required',
            ]);
            $payment = new Payments();
            if ($validator->fails()) {
                return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
            }else{
                switch ($user->valute) {
                    case 'uzs':
                     {
                        switch ($request->input('payment_type_name')) {
                            case 'uzs':
                             {

                               $payment->price = $request->input('price');
                                break;
                             }
                            case 'usd':
                             {
                               $payment->price = $request->input('price')*$val->usd;

                                break;
                             }
                            case 'rubl':
                             {
                               $payment->price = $request->input('price')*$val->rubl;
                                break;
                             }
                            default:{
                                break;
                            }
                        }
                        break;
                     }
                    case 'usd':
                     {
                        switch ($request->input('payment_type_name')) {
                            case 'uzs':
                             {

                               $payment->price = $request->input('price')/$val->usd;
                                break;
                             }
                            case 'usd':
                             {
                               $payment->price = $request->input('price');
                                break;
                             }
                            case 'rubl':
                             {
                               $payment->price = ($request->input('price')*$val->rubl)/$val->usd;
                                break;
                             }
                            default:{
                                break;
                            }
                        }
                        break;
                     }
                    case 'rubl':
                     {
                        switch ($request->input('payment_type_name')) {
                            case 'uzs':
                             {

                               $payment->price = $request->input('price')/$val->rubl;
                                break;
                             }
                            case 'usd':
                             {
                                $payment->price = ($request->input('price')*$val->usd)/$val->rubl;
                                break;
                             }
                            case 'rubl':
                             {
                               $payment->price = $request->input('price');
                                break;
                             }
                            default:{
                                break;
                            }
                        }
                        break;
                     }

                    default:{
                        break;
                    }
                }
                // $payment->price = $request->input('price');
                $user->balance =    +$user->balance+ +$payment->price;
                $payment->payment_type = $request->input('payment_type');
                $payment->payment_type_name = $request->input('payment_type_name');
                $payment->user_id = $user->id;
                $payment->user = json_encode(
                    array('login' => $user->login, 'id' => $user->id,'email' => $user->email,'img'=>$user->img,'adress'=>$user->adress,'phone'=>$user->phone,'valute'=>$user->valute)
                );
                $payment->save();
                $user->save();
                $user->balances =    +$user->balance+ +$payment->price;
                return response()->json([
                    'status'=>200,
                    'xabar'=>'Payments success!',
                    'payment' => new ResourcePayment( $payment),
                    "user" =>new ResourceUser($user)

                ]);
            }
        }else{
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }
    }
    public function paymentget(Request $request, $id=false){
        // $valute = Valute::all();
        // $user =  Auth::user() ?? false;
        // if($user &&  $user->type ?? false){
        //     if($id){
        //         $val = Valute::find($id);
        //         return $val;
        //     }else{
        //         $val = Valute::all();
        //         return $val;
        //     }
        // }else{
        //         $val = Valute::where('status', 1);
        //         return $val;
        // }
        $user = Auth::user() ?? false;
        if($user){
            $payment = ResourcePayment::collection(Payments::where('user_id', $user->id)->get());
            return $payment;
        }

    }
}
