<?php

namespace App\Http\Controllers\api\admin;

use App\Models\Hostings;
use App\Models\HostingPrice;
use Illuminate\Http\Request;
use App\Models\HostingPostEn;
use App\Models\HostingPostRu;
use App\Models\HostingPostUz;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\admin\ResourceHosting;

class HostingAdminController extends Controller
{
    //
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:hostings',
            'ssd' => 'required|numeric',
            'ram' => 'required|integer',
            'ftp' => 'required|integer',
            'email' => 'required|integer',
            'database_domain' => 'required|integer',
            'sub_domain' => 'required|integer',
            'mbs_network' => 'required|integer',
            'status' => 'required|boolean',

            'day' => 'required|numeric',
            'week' => 'required|numeric',
            'month' => 'required|numeric',
            'month_3' => 'required|numeric',
            'month_6' => 'required|numeric',
            'month_12' => 'required|numeric',
            'month_24' => 'required|numeric',

            'day_discount' => 'required|integer',
            'week_discount' => 'required|integer',
            'month_discount' => 'required|integer',
            'month_3_discount' => 'required|integer',
            'month_6_discount' => 'required|integer',
            'month_12_discount' => 'required|integer',
            'month_24_discount' => 'required|integer',

            'ens_header' => 'required',
            'ens_title' => 'required',
            'rus_header' => 'required',
            'rus_title' => 'required',
            'uzs_title' => 'required',
            'uzs_header' => 'required',

        ]);
        $hosting = new Hostings();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $hosting->name = $request->input('name');
            $hosting->ram = $request->input('ram');
            $hosting->mbs_network = $request->input('mbs_network');
            $hosting->ftp = $request->input('ftp');
            $hosting->email = $request->input('email');
            $hosting->database_domain = $request->input('database_domain');
            $hosting->sub_domain = $request->input('sub_domain');
            $hosting->ssd = $request->input('ssd');
            $hosting->status = $request->input('status');
            $hosting->save();
            $price = new HostingPrice();


            $price->day = $request->input('day');
            $price->week = $request->input('week');
            $price->month = $request->input('month');
            $price->month_3 = $request->input('month_3');
            $price->month_6 = $request->input('month_6');
            $price->month_12 = $request->input('month_12');
            $price->month_24 = $request->input('month_24');


            $price->day_discount = $request->input('day_discount');
            $price->week_discount = $request->input('week_discount');
            $price->month_discount = $request->input('month_discount');
            $price->month_3_discount = $request->input('month_3_discount');
            $price->month_6_discount = $request->input('month_6_discount');
            $price->month_12_discount = $request->input('month_12_discount');
            $price->month_24_discount = $request->input('month_24_discount');
            $price->hosting_id = $hosting->id;
            $price->save();
            $ru = new HostingPostRu();
            $en = new HostingPostEn();
            $uz = new HostingPostUz();
            $ru->title = $request->input('rus_title');
            $ru->header = $request->input('rus_header');
            $ru->post_id = $hosting->id;

            $en->title = $request->input('ens_title');
            $en->header = $request->input('ens_header');
            $en->post_id = $hosting->id;
            $uz->title = $request->input('uzs_title');
            $uz->header = $request->input('uzs_header');
            $uz->post_id = $hosting->id;
            $uz->save();
            $en->save();
            $ru->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'data add!',
                'data' => new ResourceHosting( $hosting)
            ]);
        }
    }
    // // get
    public function get(Request $request, $id=false){
        if($id){
            $hosting = new ResourceHosting( Hostings::find($id));
            return $hosting;
        }else{
            $hosting = ResourceHosting::collection( Hostings::paginate(2));
            return $hosting;
        }

    }
    // // edit
    public function edit(Request $request,$id=false){
        if($id){
        $hosting = Hostings::find($id);
            if($request->input('name')===$hosting->name){
                $validator = Validator::make($request->all(), [
                    'ssd' => 'numeric',
                    'ram' => 'numeric',
                    'ftp' => 'integer',
                    'email' => 'integer',
                    'database_domain' => 'integer',
                    'sub_domain' => 'integer',
                    'status' => 'boolean',

                    'day' => 'numeric',
                    'week' => 'numeric',
                    'month' => 'numeric',
                    'month_3' => 'numeric',
                    'month_6' => 'numeric',
                    'month_12' => 'numeric',
                    'month_24' => 'numeric',

                    'day_discount' => 'integer',
                    'week_discount' => 'integer',
                    'month_discount' => 'integer',
                    'month_3_discount' => 'integer',
                    'month_6_discount' => 'integer',
                    'month_12_discount' => 'integer',
                    'month_24_discount' => 'integer',

                    'uz_id' => 'required|integer',
                    'ru_id' => 'required|integer',
                    'en_id' => 'required|integer',
                    'price_id' => 'required|integer',
                ]);
            }else{
                $validator = Validator::make($request->all(), [
                    'name' => 'unique:hostings',
                    'ssd' => 'numeric',
                    'ram' => 'numeric',
                    'ftp' => 'integer',
                    'email' => 'integer',
                    'database_domain' => 'integer',
                    'sub_domain' => 'integer',
                    'status' => 'boolean',

                    'day' => 'numeric',
                    'week' => 'numeric',
                    'month' => 'numeric',
                    'month_3' => 'numeric',
                    'month_6' => 'numeric',
                    'month_12' => 'numeric',
                    'month_24' => 'numeric',

                    'day_discount' => 'integer',
                    'week_discount' => 'integer',
                    'month_discount' => 'integer',
                    'month_3_discount' => 'integer',
                    'month_6_discount' => 'integer',
                    'month_12_discount' => 'integer',
                    'month_24_discount' => 'integer',

                    'uz_id' => 'required|integer',
                    'ru_id' => 'required|integer',
                    'en_id' => 'required|integer',
                    'price_id' => 'required|integer',
                ],[
                    'name.unique'=>'ushbu name oldin kiritilgan',
                ]);
            }
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{

            $hosting->name = $request->input('name') ?? $hosting->name;
            $hosting->mbs_network = $request->input('mbs_network') ?? $hosting->mbs_network ;
            $hosting->ram = $request->input('ram') ?? $hosting->ram;
            $hosting->ftp = $request->input('ftp') ?? $hosting->ftp;
            $hosting->email = $request->input('email') ?? $hosting->email;
            $hosting->database_domain = $request->input('database_domain') ?? $hosting->database_domain;
            $hosting->sub_domain = $request->input('sub_domain') ?? $hosting->sub_domain;
            $hosting->ssd = $request->input('ssd') ?? $hosting->ssd;
            $hosting->status = $request->input('status') ?? $hosting->status;
            $hosting->save();

            $price = HostingPrice::find($request->input('price_id'));
            $price->day = $request->input('day') ??  $price->day;
            $price->week = $request->input('week') ??  $price->week;
            $price->month = $request->input('month') ??  $price->month;
            $price->month_3 = $request->input('month_3') ??  $price->month_3;
            $price->month_6 = $request->input('month_6') ??  $price->month_6;
            $price->month_12 = $request->input('month_12') ??  $price->month_12;
            $price->month_24 = $request->input('month_24') ??  $price->month_24;

            $price->day_discount = $request->input('day_discount') ??  $price->day_discount;
            $price->week_discount = $request->input('week_discount') ??  $price->week_discount;
            $price->month_discount = $request->input('month_discount') ??  $price->month_discount;
            $price->month_3_discount = $request->input('month_3_discount') ??  $price->month_3_discount;
            $price->month_6_discount = $request->input('month_6_discount') ??  $price->month_6_discount;
            $price->month_12_discount = $request->input('month_12_discount') ??  $price->month_12_discount;
            $price->month_24_discount = $request->input('month_24_discount') ??  $price->month_24_discount;
            $price->hosting_id = $hosting->id;
            $price->save();
            $ru = HostingPostRu::find($request->input('ru_id'));
            $en =  HostingPostEn::find($request->input('en_id'));
            $uz =  HostingPostUz::find($request->input('uz_id'));

            $ru->title  = $request->input('rus_title') ??     $ru->title;
            $ru->header = $request->input('rus_header') ??    $ru->header;
            $ru->post_id = $hosting->id;

            $en->title  = $request->input('ens_title') ??     $en->title;
            $en->header = $request->input('ens_header') ??    $en->header;
            $en->post_id = $hosting->id;
            $uz->title  = $request->input('uzs_title') ??     $uz->title;
            $uz->header = $request->input('uzs_header') ??    $uz->header;

            $uz->post_id = $hosting->id;
            $uz->save();
            $en->save();
            $ru->save();
                return response()->json([
                    'status'=>200,
                    'xabar'=>'hosting edit!',
                    'data' => new ResourceHosting( $hosting)
                ]);

            }
        }
        else{
            return response()->json([
                'status'=>404,
                'xabar'=>' hosting Not found 404',
            ]);
        }
    }
    // // // // delete
    public function delete($id=false){
        $hosting = Hostings::find($id);
        if($hosting){
            $hosting->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'hosting delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'hosting not found!'
            ]);
        }
    }
}
