<?php

namespace App\Http\Controllers\api\admin;

use App\Models\En;
use App\Models\Ru;
use App\Models\Uz;
use App\Models\Vds;
use App\Models\VdsPost;
use App\Models\VdsPostEn;
use App\Models\VdsPostRu;
use App\Models\VdsPostUz;
use App\Models\PriceProduct;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\admin\ResourceVds;
use Illuminate\Support\Facades\Validator;

class VdsAdminController extends Controller
{
    //
    public function add(Request $request){

        $validator = Validator::make($request->all(), [

            'data'=>'required|array',
            'ens_header' => 'required',
            'ens_title' => 'required',
            'rus_header' => 'required',
            'rus_title' => 'required',
            'uzs_title' => 'required',
            'uzs_header' => 'required',
            'ssd' => 'required|integer',
            'cpu' => 'required|integer',
            'name' => 'required|unique:vds',
            'mbs_network' => 'required|integer',
            'tariff' => 'required',
            'ftp' => 'required|integer',
            'email' => 'required',
            'domain' => 'required|integer',
            'cron' => 'required|integer',
            'ram' => 'required|integer',
            'status'=>'required|boolean',
            'nvm' => 'numeric',
            'protsessor' => 'required',

        ]);
        $vds = new Vds();

        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $vds->domain = $request->input('domain');
            $vds->ftp = $request->input('ftp');
            $vds->ssd = $request->input('ssd');
            $vds->cpu = $request->input('cpu');
            $vds->name = $request->input('name');
            $vds->mbs_network = $request->input('mbs_network');
            $vds->tariff = $request->input('tariff');
            $vds->ram = $request->input('ram');
            $vds->nvm = $request->input('nvm');
            $vds->protsessor = $request->input('protsessor');
            $vds->email = $request->input('email');
            $vds->status = $request->input('status');
            $vds->cron = $request->input('cron');
            $vds->save();

            foreach ($request->input('data') as $key => $value) {
                $price = new PriceProduct();
                $price->date = $value['date'];
                $price->date_name = $value['date_name'];
                $price->discount = $value['discount'];
                $price->price = $value['price'];
                $price->servis_time = $value['servis_time'];
                $price->install_price = $value['install_price'];
                $price->vds_id = $vds->id;
                $price->save();
            }
            $ru = new VdsPostRu();
            $en = new VdsPostEn();
            $uz = new VdsPostUz();
            $ru->title = $request->input('rus_title');
            $ru->header = $request->input('rus_header');
            $ru->post_id = $vds->id;

            $en->title = $request->input('ens_title');
            $en->header = $request->input('ens_header');
            $en->post_id = $vds->id;
            $uz->title = $request->input('uzs_title');
            $uz->header = $request->input('uzs_header');
            $uz->post_id = $vds->id;
            $uz->save();
            $en->save();
            $ru->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'vds add!',
                'data' => new ResourceVds($vds)
            ]);
        }
    }
    // // get
    public function get(Request $request, $id=false){
        if($id){
            $vds = new ResourceVds( Vds::find($id));
            return $vds;
        }else{
            $vds = ResourceVds::collection(Vds::with('price')->paginate(10));
            return $vds;
        }

    }
    public function edit(Request $request,$id=false){
        if($id){
        $vds = Vds::find($id);
            if($request->input('name')===$vds->name){
                $validator = Validator::make($request->all(), [
                    'data'=>'array',
                    'delete'=>'array',
                    'mbs_network' => 'integer',
                    'ftp' => 'integer',
                    'domain' => 'integer',
                    'cron' => 'integer',
                    'ram' => 'integer',
                    'status'=>'boolean',
                    'nvm' => 'numeric',
                ]);
            }else{
                $validator = Validator::make($request->all(), [
                    'data'=>'array',
                    'delete'=>'array',
                    'name' => 'unique:vds',
                    'mbs_network' => 'integer',
                    'ftp' => 'integer',
                    'domain' => 'integer',
                    'cron' => 'integer',
                    'ram' => 'integer',
                    'status'=>'boolean',
                    'nvm' => 'numeric',

                ],[
                    'name.unique'=>'ushbu name oldin kiritilgan',
                ]);
            }
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{

            $vds->domain = $request->input('domain') ?? $vds->domain;
            $vds->ftp = $request->input('ftp')   ?? $vds->ftp;
            $vds->ssd = $request->input('ssd')  ?? $vds->ssd;
            $vds->cpu = $request->input('cpu')  ?? $vds->cpu;
            $vds->name = $request->input('name')  ?? $vds->name;
            $vds->mbs_network = $request->input('mbs_network')  ?? $vds->mbs_network;
            $vds->tariff = $request->input('tariff')  ?? $vds->tariff;
            $vds->ram = $request->input('ram')  ?? $vds->ram;
            $vds->nvm = $request->input('nvm')  ?? $vds->nvm;
            $vds->protsessor = $request->input('protsessor')  ?? $vds->protsessor;
            $vds->email = $request->input('email')  ?? $vds->email;
            $vds->status = $request->input('status')  ?? $vds->status;
            $vds->cron = $request->input('cron')  ?? $vds->cron;
            $vds->save();

            foreach ($request->input('data') as $key => $value) {
                $price = PriceProduct::find($value['id']);
                if($price){
                    $price->date = $value['date'] ??   $price->date ;
                    $price->date_name = $value['date_name'] ??  $price->date_name;
                    $price->discount = $value['discount'] ??  $price->discount;
                    $price->price = $value['price'] ??  $price->price;
                    $price->servis_time = $value['servis_time'] ??  $price->servis_time;
                    $price->install_price = $value['install_price'] ??  $price->install_price;
                    $price->vds_id = $vds->id;
                    $price->save();
                }else{
                    $pricenew = new PriceProduct();
                    $pricenew->date = $value['date'];
                    $pricenew->date_name = $value['date_name'];
                    $pricenew->discount = $value['discount'];
                    $pricenew->price = $value['price'];
                    $pricenew->servis_time = $value['servis_time'];
                    $pricenew->install_price = $value['install_price'];
                    $pricenew->vds_id = $vds->id;
                    $pricenew->save();
                }
            }
            if(count($request->input('delete'))>0){
                foreach ($request->input('delete') as $key => $value) {
                    $pricedelete = PriceProduct::find($value['id']);
                    $pricedelete->delete();
                }
            }
            $ru = VdsPostRu::find($request->input('ru_id'));
            $en =  VdsPostEn::find($request->input('en_id'));
            $uz =  VdsPostUz::find($request->input('uz_id'));
            $ru->title = $request->input('rus_title') ?? $ru->title;
            $ru->header = $request->input('rus_header') ?? $ru->header;
            $ru->post_id = $vds->id;

            $en->title = $request->input('ens_title') ?? $en->title;
            $en->header = $request->input('ens_header') ?? $en->header;
            $en->post_id = $vds->id;
            $uz->title = $request->input('uzs_title') ??   $uz->title;
            $uz->header = $request->input('uzs_header') ??   $uz->header;
            $uz->post_id = $vds->id;
            $uz->save();
            $en->save();
            $ru->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'vds yangilandi!',
                'data' => new ResourceVds($vds)
            ]);

            }
        }
        else{
            return response()->json([
                'status'=>404,
                'xabar'=>'Not found 404',
            ]);
        }
    }
    // // // // delete
    public function delete($id=false){
        $vds = Vds::find($id);
        if($vds){
            $vds->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'vds delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'vds not found!'
            ]);
        }
    }
}
