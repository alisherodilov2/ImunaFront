<?php

namespace App\Http\Controllers\api\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminNewsController extends Controller
{
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'uz_title' => 'required',
            'ru_title' => 'required',
            'en_title' => 'required',
            'uz_title' => 'required',
            'ru_title' => 'required',
            'en_title' => 'required',
            'goverment' => 'required',
            'year_price' => 'required|numeric',
            'discount' => 'required|integer',
            'status' => 'required',
        ]);
        $domintype = new DomainTypes();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $domintype->type = $request->input('type');
            $domintype->goverment = $request->input('goverment');
            $domintype->year_price = $request->input('year_price');
            $domintype->discount = $request->input('discount');
            $domintype->status = $request->input('status');
            $domintype->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype add!',
                'data' => $domintype
            ]);
        }
    }
    // // get
    public function get(Request $request, $id=false){
        if($id){
            $domintype = DomainTypes::find($id);
            return $domintype;
        }else{
            $domintype = DomainTypes::paginate(2);
            return $domintype;
        }

    }
    // // edit
    public function edit(Request $request,$id=false){
        if($id){
        $domintype = DomainTypes::find($id);
            if($request->input('type')===$domintype->type){
                $validator = Validator::make($request->all(), [
                    'year_price' => 'numeric',
                    'discount' => 'integer',
                ]);
            }else{
                $validator = Validator::make($request->all(), [
                    'type' => 'unique:domain_types',
                    'year_price' => 'numeric',
                    'discount' => 'integer',
                ],[
                    'type.unique'=>'ushbu domain_types oldin kiritilgan',
                ]);
            }
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{

                $domintype->type = $request->input('type') ?? $domintype->type;
                $domintype->goverment = $request->input('goverment') ?? $domintype->goverment;
                $domintype->year_price = $request->input('year_price') ?? $domintype->year_price;
                $domintype->discount = $request->input('discount') ?? $domintype->discount;
                $domintype->status = $request->input('status') ?? $domintype->status;
                $domintype->save();
                return response()->json([
                    'status'=>200,
                    'xabar'=>'domintype edit!',
                    'data' => $domintype
                ]);

            }
        }
        else{
            return response()->json([
                'status'=>404,
                'xabar'=>'Not found 404',
            ]);
        }
    }
    // // // // delete
    public function delete($id=false){
        $domintype = DomainTypes::find($id);
        if($domintype){
            $domintype->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'domintype not found!'
            ]);
        }
    }
}
