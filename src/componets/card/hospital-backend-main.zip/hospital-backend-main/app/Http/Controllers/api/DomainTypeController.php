<?php

namespace App\Http\Controllers\api;

use App\Models\DomainTypes;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\user\ResourceDomainType;

class DomainTypeController extends Controller
{
    // // get
    public function get(Request $request, $id=false){
        if($id){
            $domintype = new ResourceDomainType( DomainTypes::where(['status'=> 1,'id'=>$id])->first());
            return $domintype;
        }else{
            $domintype =ResourceDomainType::collection( DomainTypes::where(['status'=> 1])->get());
            return $domintype;
        }

    }
}
