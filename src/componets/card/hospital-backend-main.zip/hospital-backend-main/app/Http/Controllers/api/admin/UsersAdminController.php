<?php

namespace App\Http\Controllers\api\admin;

use App\Models\User;
use App\Models\Payments;
use App\Models\DomainOrders;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UsersAdminController extends Controller
{
    //
    public function get(Request $request, $id=false){
        if($id){
            $order = DomainOrders::where('user_id',$id)->get();
            $payment = Payments::where('user_id', $id)->get();
            $user = User::find($id);
            return array('hostingorder' => $order, 'user' => $user, 'payment' => $payment);
        }else{
            $user = User::all();
            return $user;
        }
    }
}
