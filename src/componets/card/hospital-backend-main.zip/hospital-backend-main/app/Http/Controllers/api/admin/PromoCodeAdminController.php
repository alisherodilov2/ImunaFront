<?php

namespace App\Http\Controllers\api\admin;

use App\Models\PromoCodes;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class PromoCodeAdminController extends Controller
{
    //add
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'price' => 'required|numeric|min:1',
            'hosting' => 'required|numeric|min:1',
            'domain' => 'required|numeric|min:1',
            'vds' => 'required|numeric|min:1',
            'vps' => 'required|integer|min:1',
            'sms' => 'required|integer|min:1',
            'limit' => 'required|integer|min:1',
            'discount' => 'required|integer|min:1',
            'status' => 'required|boolean',
        ]);
        $promocode = new PromoCodes();
        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $promocode->price = $request->input('price');
            $promocode->hosting = $request->input('hosting');
            $promocode->domain = $request->input('domain');
            $promocode->vds = $request->input('vds');
            $promocode->limit = $request->input('limit');
            $promocode->vps = $request->input('vps');
            $promocode->sms = $request->input('sms');
            $promocode->code = Hash::make(date('Y-m-d H:i:s:m'));
            $promocode->discount = $request->input('discount');
            $promocode->status = $request->input('status');
            $promocode->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'domintype add!',
                'data' =>$promocode
            ]);
        }
    }
    // get
    public function get(Request $request, $id=false){
        if($id){
            $promocode = PromoCodes::find($id);
            return $promocode;
        }else{
            $promocode = PromoCodes::paginate(2);
            return $promocode;
        }

    }
    // // edit
    public function edit(Request $request,$id=false){
            if ($id) {
                $promocode = PromoCodes::find($id) ?? false;
                if ($promocode) {
                    $validator = Validator::make($request->all(), [
                        'price' => 'numeric|min:1',
                        'hosting' => 'numeric|min:1',
                        'domain' => 'numeric|min:1',
                        'vds' => 'numeric|min:1',
                        'vps' => 'integer|min:1',
                        'sms' => 'integer|min:1',
                        'limit' => 'integer|min:1',
                        'discount' => 'integer|min:1',
                        'status' => 'boolean',
                    ]);
                    if ($validator->fails()) {
                        return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
                    } else {
                        $promocode->price = $request->input('price') ?? $promocode->price;
                        $promocode->hosting = $request->input('hosting') ?? $promocode->hosting;
                        $promocode->domain = $request->input('domain') ?? $promocode->domain;
                        $promocode->vds = $request->input('vds') ?? $promocode->vds;
                        $promocode->vps = $request->input('vps') ?? $promocode->vps;
                        $promocode->sms = $request->input('sms') ?? $promocode->sms;
                        $promocode->limit = $request->input('limit') ?? $promocode->limit;
                        $promocode->discount = $request->input('discount') ?? $promocode->discount;
                        $promocode->status = $request->input('status') ?? $promocode->status;
                        $promocode->save();
                        return response()->json([
                            'status'=>200,
                            'xabar'=>'promocode edit!',
                            'data' => $promocode
                        ]);
                    }
                } else {
                    return response()->json([
                        'status'=>404,
                        'xabar'=>'Not found 404',
                    ]);
                }
            }else {
                return response()->json([
                    'status'=>404,
                    'xabar'=>'Not found 404',
                ]);
            }
    }
    // // // // delete
    public function delete($id=false){
        $promocode = PromoCodes::find($id);
        if($promocode){
            $promocode->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'pro$promocode delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'domintype not found!'
            ]);
        }
    }
}
