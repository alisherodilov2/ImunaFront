<?php

namespace App\Http\Controllers\api\admin;

use Illuminate\Http\Request;
use App\Models\ReselingServers;
use App\Http\Controllers\Controller;
use App\Http\Resources\ResourceReselings;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\admin\ResourceReselingServer;

class ReselingServerAdminController extends Controller
{
         public function add(Request $request){
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'pop3' => 'required',
                // 'reseling' => 'required',
                // 'users' => 'required|integer',
                'ftp' => 'required|integer',
                'reseling_id' => 'required|integer',
                'domain' => 'required|integer',
                'sub_domain' => 'required|integer',
                'day_price' => 'required|numeric',
                'month_price' => 'required|numeric',
                'year_price' => 'required|numeric',
                'memory' => 'required|integer',
                'status' => 'required|boolean',
            ]);
            $reselingserver = new ReselingServers();
            if ($validator->fails()) {
                return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
            }else{

                $reselingserver->name = $request->input('name');
                $reselingserver->pop3 = $request->input('pop3');
                $reselingserver->users = 0;
                $reselingserver->reseling_id = $request->input('reseling_id');
                // $reselingserver->reseling = $request->input('reseling');
                $reselingserver->ftp = $request->input('ftp');
                $reselingserver->domain = $request->input('domain');
                $reselingserver->sub_domain = $request->input('sub_domain');
                $reselingserver->day_price = $request->input('day_price');
                $reselingserver->month_price = $request->input('month_price');
                $reselingserver->year_price = $request->input('year_price');
                $reselingserver->memory = $request->input('memory');
                $reselingserver->status = $request->input('status');
                $reselingserver->save();
                return response()->json([
                    'status'=>200,
                    'xabar'=>'resl add!',
                    'data' =>new ResourceReselingServer($reselingserver)
                ]);
            }
        }
        // get
        public function get(Request $request, $id=false){
            if($id){
                $reselingserver = new ResourceReselingServer(ReselingServers::find($id));
                return $reselingserver;
            }else{
                   $reselingserver = ResourceReselingServer::collection(ReselingServers::with('reselingData')->paginate(10));
                //    $reselingserver = ReselingServers::with('reselingData')->get();
                // $reselingserver = ReselingServers::paginate(2);
                return $reselingserver;
            }

        }
        // // edit
        public function edit(Request $request,$id=false){
                if ($id) {
                    $reselingserver = ReselingServers::find($id) ?? false;
                    if ($reselingserver) {
                        $validator = Validator::make($request->all(), [
                            'users' => 'integer',
                            'ftp' => 'integer',
                            'domain' => 'integer',
                            'sub_domain' => 'integer',
                            'day_price' => 'numeric',
                            'month_price' => 'numeric',
                            'year_price' => 'numeric',
                            'memory' => 'integer',
                            'status' => 'boolean',
                            'reseling_id' => 'integer',
                        ]);
                        if ($validator->fails()) {
                            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
                        } else {
                            $reselingserver->name = $request->input('name') ?? $reselingserver->name;
                            $reselingserver->pop3 = $request->input('pop3') ?? $reselingserver->pop3;
                            $reselingserver->reseling_id = $request->input('reseling_id') ?? $reselingserver->reseling_id;
                            $reselingserver->reseling = $request->input('reseling') ?? $reselingserver->reseling;
                            $reselingserver->users = $request->input('users') ?? $reselingserver->users;
                            $reselingserver->ftp = $request->input('ftp') ?? $reselingserver->ftp;
                            $reselingserver->domain = $request->input('domain') ?? $reselingserver->domain;
                            $reselingserver->sub_domain = $request->input('sub_domain') ?? $reselingserver->sub_domain;
                            $reselingserver->day_price = $request->input('day_price') ?? $reselingserver->day_price;
                            $reselingserver->month_price = $request->input('month_price') ?? $reselingserver->month_price;
                            $reselingserver->year_price = $request->input('year_price') ?? $reselingserver->year_price;
                            $reselingserver->memory = $request->input('memory') ?? $reselingserver->memory;
                            $reselingserver->status = $request->input('status') ?? $reselingserver->status;
                            return response()->json([
                                'status'=>200,
                                'xabar'=>'rese$reseling edit!',
                                'data' => new ResourceReselingServer($reselingserver)
                            ]);
                        }
                    } else {
                        return response()->json([
                            'status'=>404,
                            'xabar'=>'Not found 404',
                        ]);
                    }
                }else {
                    return response()->json([
                        'status'=>404,
                        'xabar'=>'Not found 404',
                    ]);
                }
        }
        // // // // delete
        public function delete($id=false){
            $reseling = ReselingServers::find($id);
            if($reseling){
                $reseling->delete();
                return response()->json([
                    'status'=>200,
                    'xabar'=>'pro$reseling delete!'
                ]);
            }else{
                return response()->json([
                    'status'=>404,
                    'xabar'=>'domintype not found!'
                ]);
            }
        }
}
