<?php

namespace App\Http\Controllers\api;

use App\Models\Vds;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\user\ResourceVds;
use Illuminate\Support\Facades\Validator;

class VdsController extends Controller
{
    //
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'price_1' => 'required|numeric',
            'price_2' => 'required|numeric',
            'price_3' => 'required|numeric',
            'price_4' => 'required|numeric',
            'ssd' => 'required|integer',
            'cpu' => 'required|integer',
            'name' => 'required|integer',
            'mbs_network' => 'required|integer',
            'tariff' => 'required|integer',
            'ftp' => 'required|integer',
            'email' => 'required',
            'domain' => 'required|integer',
            'cron' => 'required|integer',
            'ram' => 'required|integer',
        ]);
        $vds = new Vds();

        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $vds->domain = $request->input('domain');
            $vds->price_1 = $request->input('price_1');
            $vds->price_2 = $request->input('price_2');
            $vds->price_3 = $request->input('price_3');
            $vds->price_4 = $request->input('price_4');
            $vds->ftp = $request->input('ftp');
            $vds->ssd = $request->input('ssd');
            $vds->cpu = $request->input('cpu');
            $vds->name = $request->input('name');
            $vds->mbs_network = $request->input('mbs_network');
            $vds->tariff = $request->input('tariff');
            $vds->ram = $request->input('ram');
            $vds->email = $request->input('email');
            $vds->cron = $request->input('cron');
            $vds->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'vds add!',
                'group' => $vds
            ]);

        }
    }
    // // get
    public function get(Request $request, $id=false){
        if($id){
            $vds =new ResourceVds( Vds::where(['status'=> 1,'id'=>$id])->first());
            return $vds;
        }else{
            $vds = ResourceVds::collection( Vds::where('status',1)->get());
            return $vds;
        }

    }
}
