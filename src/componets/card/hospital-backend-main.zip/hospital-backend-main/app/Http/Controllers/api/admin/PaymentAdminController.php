<?php

namespace App\Http\Controllers\api\admin;

use App\Models\Payments;
use App\Models\DomainTypes;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PaymentAdminController extends Controller
{
    //get
    public function get(Request $request, $id=false){
        if($id){
            $pay = Payments::find($id);
            return $pay;
        }else{
            $pay = Payments::all();
            return $pay;
        }
    }
    public function delete($id=false){
        $payment = Payments::find($id);
        if($payment){
            $payment->delete();
            return response()->json([
                'status'=>200,
                'xabar'=>'payment delete!'
            ]);
        }else{
            return response()->json([
                'status'=>404,
                'xabar'=>'payment not found!'
            ]);
        }
    }
}
