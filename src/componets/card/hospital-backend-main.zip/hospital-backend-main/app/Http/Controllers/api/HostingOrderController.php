<?php

namespace App\Http\Controllers\api;

use App\Models\Hostings;
use Illuminate\Http\Request;
use App\Models\HostingOrders;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\user\ResourceUser;
use App\Http\Resources\user\ResourceHostingOrder;

class HostingOrderController extends Controller
{
    //
    public function order(Request $request){
        $user = Auth::user() ?? false;
        if($user){
        $hostingOrder = new HostingOrders();
        $hostingOrder->user_id = $user->id;
        $hostingOrder->price =  $request->input('price');
        $user->balance = $user->balance-$request->input('price');
        $user->save();
        $now = date('Y-m-d H:i:s');
        $hostingOrder->start_date =  $now ;
        $hostingOrder->end_date = date('Y-m-d H:i:s',strtotime( $now."+ ".$request->input('data')."month") ) ;
        $hostingOrder->user = json_encode($user);
        $hostingOrder->hosting_id = $request->input('hosting_id');
        $hostingOrder->status = 'tolandi';
        $hostingOrder->hosting =json_encode(Hostings::find($request->input('id')));
        $hostingOrder->save();
        $user['balances'] = +$user->balance;
        return response()->json([
            'status'=>200,
            "user" =>new ResourceUser($user),
            'data'=>new ResourceHostingOrder( $hostingOrder)
        ]);
        }
    }
    public function get(Request $request, $id=false){
        $user = Auth::user();
        if($id){
            $hostingorder = new ResourceHostingOrder( HostingOrders::find($id));
            return $hostingorder;
        }else{
            $hostingorder = ResourceHostingOrder::collection(HostingOrders::where('user_id', $user->id)->get());
            return $hostingorder;
        }
    }
}
