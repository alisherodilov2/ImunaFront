<?php

namespace App\Http\Controllers\api;

use App\Models\DomainOrders;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class DomainOrderController extends Controller
{
    //
    public function domainorder(Request $request){
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'domain_id' => 'required|integer',
            'user_id' => 'required|integer',
            'user' => 'required',
            'domain' => 'required',
            'domain_price' => 'required|numeric',
            'status' => 'required',
        ]);

        $domainorder = new DomainOrders();

        if ($validator->fails()) {
            return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
        }else{
            $domainorder->type = $request->input('type');
            $domainorder->domain_id = $request->input('domain_id');
            $domainorder->user_id = $request->input('user_id');
            $domainorder->user = $request->input('user');
            $domainorder->domain = $request->input('domain');
            $domainorder->domain_price = $request->input('domain_price');
            $domainorder->status = $request->input('status');
            $user = Auth::user();
            $user['balance'] = +$user->balance - +$request->input('domain_price');
            $user->save();
            $user['balances'] = +$user->balance;
            $domainorder->save();
            return response()->json([
                'status'=>200,
                'xabar'=>'domainorder add!',
                'group' => $domainorder,
                'user' => $user
            ]);

        }
    }
    // // get
    public function get(Request $request, $id=false){
        $user = Auth::user();
        if($id){
            $domainorder = DomainOrders::where('id',$user->id)->get();
            return $domainorder;
        }else{
            $domainorder = DomainOrders::where('user_id',$user->id)->get();
            return $domainorder;
        }

    }
    // // edit
    // public function edit(Request $request,$id=false){
    //     $validator = Validator::make($request->all(), [
    //         'moth_price' => 'required|numeric',
    //         'year_price' => 'required|numeric',
    //         'discount' => 'required|integer',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json(['xatolik' => 'malumot turida xatolik bor','message' => $validator->messages()]);
    //     }else{
    //         if($id){
    //             $domintype = DomainTypes::find($id);
    //             $domintype->type = $request->input('type') ?? $domintype->type;
    //             $domintype->goverment = $request->input('goverment') ?? $domintype->goverment;
    //             $domintype->moth_price = $request->input('moth_price') ?? $domintype->moth_price;
    //             $domintype->year_price = $request->input('year_price') ?? $domintype->year_price;
    //             $domintype->discount = $request->input('discount') ?? $domintype->discount;
    //             $domintype->status = $request->input('status') ?? $domintype->status;
    //             $domintype->save();
    //             return response()->json([
    //                 'status'=>200,
    //                 'xabar'=>'domintype edit!',
    //                 'group' => $domintype
    //             ]);

    //         }else{
    //             return response()->json([
    //                 'status'=>404,
    //                 'xabar'=>'Not found 404',
    //             ]);

    //         }
    //     }


    // }
    // // // // // delete
    // public function delete($id=false){
    //     $domintype = DomainTypes::find($id);
    //     if($domintype){
    //         $domintype->delete();
    //         return response()->json([
    //             'status'=>200,
    //             'xabar'=>'domintype delete!'
    //         ]);
    //     }else{
    //         return response()->json([
    //             'status'=>404,
    //             'xabar'=>'domintype not found!'
    //         ]);
    //     }
    // }
}
