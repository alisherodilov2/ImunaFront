Hey {{$name}},
Can your Laravel app send emails yet? 😉
Mailtrap
