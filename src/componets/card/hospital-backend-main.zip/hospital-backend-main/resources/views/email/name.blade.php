<div>
    Hi, mail sent..
    <h1>
        {{ $detil['title'] }}
    </h1>
    <p>
        {{ $detil['body'] }}
    </p>
</div>
