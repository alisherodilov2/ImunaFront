<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePatientPersonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_persons', function (Blueprint $table) {
            $table->increments('id');
            $table->string('last_name');
            $table->string('first_name');
            $table->string('parent_name');
            $table->string('passport');
            $table->string('address');
            $table->string('region_extra'); /// qoshimcha mazil
            $table->string('disability'); /// nogironlik
            $table->unsignedInteger('region_id')->default(null);
            $table->foreign('region_id')
                ->references('id')
                ->on('regions')
                ->constrained()
                ->onDelete('cascade')
                ->onUpdate('cascade')
                ->nullable();
            $table->unsignedInteger('user_id')->default(null);
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->constrained()
                ->onDelete('cascade')
                ->onUpdate('cascade')
                ->nullable();
            $table->string('diagnosis_year'); /// Tashxis qo'yilgan yil
            $table->string('register_date'); /// Дата постановки на учет Ro'yxatdan o'tish sanasi
            $table->string('katta_end_date'); ///Дата заполнения карты Karta tugallangan sana
            $table->string('birthday'); ///tugulgan sana
            $table->boolean('pol'); /// m,j
            $table->boolean('live_type'); //selo,shahar Тип проживания Turar joy turi
            $table->unsignedInteger('diabete_types_id')->default(null);
            $table->foreign('diabete_types_id')
                ->references('id')
                ->on('diabete_types')
                ->constrained()
                ->onUpdate('cascade')
                ->onDelete('cascade')
                ->nullable();
                $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_persons');
    }
}
