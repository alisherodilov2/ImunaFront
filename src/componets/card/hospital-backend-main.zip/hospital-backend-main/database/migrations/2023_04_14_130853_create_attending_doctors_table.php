<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendingDoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attending_doctors', function (Blueprint $table) {
            $table->increments('id');
            $table->string('institution'); //// qandaydir qvp
            $table->boolean('pol'); /// m,j
            $table->string('last_name');
            $table->string('first_name');
            $table->string('parent_name');
            $table->string('direction');
            $table->unsignedInteger('region_id')->default(null);
            $table->foreign('region_id')
                ->references('id')
                ->on('regions')
                ->constrained()
                ->onDelete('cascade')
                ->onUpdate('cascade')
                ->nullable();
            $table->unsignedInteger('user_id')->default(null);
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->constrained()
                ->onDelete('cascade')
                ->onUpdate('cascade')
                ->nullable();
            $table->softDeletes();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attending_doctors');
    }
}
